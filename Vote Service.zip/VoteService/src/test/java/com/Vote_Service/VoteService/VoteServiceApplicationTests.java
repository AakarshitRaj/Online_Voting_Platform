package com.Vote_Service.VoteService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VoteServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
