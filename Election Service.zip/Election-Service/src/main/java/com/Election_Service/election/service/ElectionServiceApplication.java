package com.Election_Service.election.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElectionServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ElectionServiceApplication.class, args);
	}

}
